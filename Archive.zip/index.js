'use strict';

const server = require('./src/server');

server.start();
